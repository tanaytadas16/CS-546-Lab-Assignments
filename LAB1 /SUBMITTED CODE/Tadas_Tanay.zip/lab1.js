// Question 1
const questionOne = function questionOne(arr) {
    var obj={}
    var pri=true;
    if (arr === undefined || arr===[]||arr===null||arr==={})
        return {}
    else
    { 
      for(let i=0;i<arr.length;i++){
            var res= Math.abs((Math.pow(arr[i],2))-7);
            if(res===2)
            {
                pri=true;
            }
            else if(res>1&&res!=2){
                    for(let i=2;i<res;i++)
                    {
                        if (res%i===0)
                            pri=false;
                            break;
                    }
            } 
           
        obj[res]=pri;
        }
    }
    
    return obj;
}

// Question Two
const questionTwo = function questionTwo(arr) { 
    if(arr===null || arr===undefined||arr===[])
        return []
    var arr2=[];
    arr2=[...new Set(arr)]
 return arr2
}

//Question Three
const questionThree = function questionThree(arr) {
    var strs=[...new Set(arr)]
    let result={}
    let result1 ={}
    let result2={}
    if(strs==undefined|| strs.length==0){
        return {}
    }
    else{
  for (let word of strs) {
      var sorted = word.split("").sort().join("");
      if (result[sorted]) {
        result[sorted].push(word);
      } else {
        result[sorted] = [word];
      }
    }

    for(let i=0;i<Object.keys(result).length;i++)
    {
            if((Object.values(result)[i].length)>=2)
            {
                result1=Object.values(result)[i]
                var ky=Object.keys(result)[i]
                var res=Object.values(result)[i]
                result2[ky]=res
                
            }
    }
    return result2;
    
}
}


//Question Four
const questionFour = function questionFour(num1, num2, num3) {
    const fact=(n)=>{
        if(n==0)
            return 1;
        else
            return n*fact(n-1)
    }
    const add= fact(num1)+fact(num2)+fact(num3)
    const avg=(num1+num2+num3)/3;
    return Math.floor(add/avg)  
}

module.exports = {
    firstName: "TANAY", 
    lastName: "TADAS", 
    studentId: "10478620",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};