const lab1=require("./lab1");

console.log(lab1.questionOne([2, 5, 9, 7 ])); 
//returns and outputs: { '3': true, '18': false, '42': false, '74': false }

console.log(lab1.questionOne([2])); 
// returns and outputs: {'3': true} 

console.log(lab1.questionOne([4,8])); 
// returns and outputs: { '9': true, '57': true }

console.log(lab1.questionOne()); 
// returns and outputs: {}

console.log(lab1.questionOne([])); 
// returns and outputs: {}




console.log(lab1.questionTwo([1, 1, 1, 1, 1, 1])); 
//returns and outputs: [1]

console.log(lab1.questionTwo([1, '1', 1, '1', 2])); 
// returns and outputs: [1, '1', 2] 

console.log(lab1.questionTwo(['a', 'a', 'b', 3, 'b'])); 
// returns and outputs: [ 'a', 'b', 3 ]

console.log(lab1.questionTwo(['s','sd','4','sd',4])); 
//returns and outputs: [ 's', 'sd', '4', 4 ]

console.log(lab1.questionTwo([])); 
//returns and outputs: []




console.log(lab1.questionThree(["cat", "act", "foo", "bar"])); 
// returns and outputs: { act: ["cat", "act"] }

console.log(lab1.questionThree(["race", "care", "foo", "foo", "foo"]));
// returns and outputs: { acer: ["race", "care"] } 

console.log(lab1.questionThree(["foo", "bar", "test", "Tanay", "Tadas"]));
// returns and outputs: {}

console.log(lab1.questionThree(["cat", "act", "race", "care"])); 
// returns and outputs: {}

console.log(lab1.questionThree([])); 
// returns and outputs: {}






console.log(lab1.questionFour(1, 3, 2)); 
//returns and outputs: 4

console.log(lab1.questionFour(2, 4, 7)); 
//returns and outputs: 1169 

console.log(lab1.questionFour(11, 4, 2)); 
//returns and outputs: 7044145

console.log(lab1.questionFour(5, 6, 7)); 
//returns and outputs: 980 

console.log(lab1.questionFour(4, 5, 6)); 
//returns and outputs: 172