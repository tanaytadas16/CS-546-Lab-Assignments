const restdata = require('./restaurants');
const reviewdata = require('./reviews');

module.exports = {
    restaurants: restdata,
    reviews: reviewdata,
};
