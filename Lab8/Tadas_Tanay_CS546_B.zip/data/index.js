const getcharacters = require('./characters');
module.exports = {
    characters: getcharacters,
};
