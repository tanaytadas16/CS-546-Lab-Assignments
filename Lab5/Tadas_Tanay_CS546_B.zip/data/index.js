const getPeople = require('./people');
const getStocks = require('./stocks');
module.exports = {
    people: getPeople,
    stocks: getStocks,
};
